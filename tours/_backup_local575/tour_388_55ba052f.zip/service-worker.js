
const CACHE_NAME = 'tour-cache-v1';
const urlsToCache = [
  '/',
  '/index.html'
];

// Cache audio and text files dynamically
self.addEventListener('fetch', function(event) {
  if (event.request.url.includes('.mp3') || event.request.url.includes('.txt')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(function(cache) {
        return cache.match(event.request).then(function(response) {
          return response || fetch(event.request).then(function(response) {
            cache.put(event.request, response.clone());
            return response;
          });
        });
      })
    );
  }
});

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        return cache.addAll(urlsToCache);
      })
  );
});
